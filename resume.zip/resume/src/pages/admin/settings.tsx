import { useState } from 'react'
import Head from 'next/head'
import AdminLayout from '@/components/AdminLayout'

export default function AdminSettings() {
  const [settings, setSettings] = useState({
    maintenanceMode: false,
  })

  const handleSave = () => {
    alert('Settings saved successfully!')
  }

  return (
    <>
      <Head>
        <title>Settings - Admin</title>
      </Head>

      <AdminLayout activePage="settings">
        <div className="admin-content">
          <div style={{ marginBottom: '2rem' }}>
            <h2 style={{ margin: '0 0 0.5rem 0', color: '#1e293b' }}>
              <i className="fas fa-cog"></i> Admin Settings
            </h2>
            <p style={{ margin: 0, color: '#64748b' }}>
              Configure platform settings and preferences
            </p>
          </div>

          <div style={{ display: 'grid', gap: '1.5rem' }}>
            {/* System Settings */}
            <div style={{ padding: '1.5rem', background: 'white', border: '1px solid #e2e8f0', borderRadius: '12px' }}>
              <h3 style={{ margin: '0 0 1.5rem 0', color: '#1e293b' }}>System Settings</h3>
              
              <div style={{ display: 'grid', gap: '1rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={settings.maintenanceMode}
                    onChange={(e) => setSettings({...settings, maintenanceMode: e.target.checked})}
                    style={{ width: '20px', height: '20px', cursor: 'pointer' }}
                  />
                  <div>
                    <p style={{ margin: 0, color: '#1e293b', fontWeight: 600 }}>Maintenance Mode</p>
                    <p style={{ margin: '0.25rem 0 0 0', color: '#64748b', fontSize: '0.9rem' }}>
                      Put the site in maintenance mode (only admins can access)
                    </p>
                  </div>
                </label>
              </div>
            </div>

            {/* Save Button */}
            <div style={{ display: 'flex', gap: '1rem' }}>
              <button 
                onClick={handleSave}
                style={{
                  padding: '0.875rem 2rem',
                  background: '#667eea',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontWeight: 600,
                  fontSize: '1rem'
                }}
              >
                <i className="fas fa-save"></i> Save Settings
              </button>
              <button 
                style={{
                  padding: '0.875rem 2rem',
                  background: 'white',
                  color: '#64748b',
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontWeight: 600,
                  fontSize: '1rem'
                }}
              >
                <i className="fas fa-undo"></i> Reset
              </button>
            </div>
          </div>
        </div>
      </AdminLayout>
    </>
  )
}
