import { useState } from 'react'
import Head from 'next/head'
import AdminLayout from '@/components/AdminLayout'
import Image from 'next/image'

export default function AdminDashboard() {
  const [jobs, setJobs] = useState([
    { 
      id: 1, 
      title: 'Senior Software Engineer', 
      company: 'Tech Corp Inc.', 
      location: 'San Francisco, CA', 
      salary: '$120k - $180k', 
      status: 'Active', 
      logo: '/placeholder-logo.png',
      type: 'Full-time',
      description: 'We are looking for an experienced Senior Software Engineer to join our team...',
      requirements: 'Bachelor\'s degree in Computer Science, 5+ years of experience',
      postedDate: '2024-12-01',
      applications: 45
    },
    { 
      id: 2, 
      title: 'Product Designer', 
      company: 'Design Studio', 
      location: 'Remote', 
      salary: '$90k - $130k', 
      status: 'Active', 
      logo: '/placeholder-logo.png',
      type: 'Full-time',
      description: 'Join our creative team as a Product Designer...',
      requirements: 'Portfolio required, 3+ years of UI/UX design experience',
      postedDate: '2024-11-28',
      applications: 32
    },
    { 
      id: 3, 
      title: 'Marketing Manager', 
      company: 'Growth Co', 
      location: 'New York, NY', 
      salary: '$80k - $110k', 
      status: 'Inactive', 
      logo: '/placeholder-logo.png',
      type: 'Full-time',
      description: 'Lead our marketing initiatives and drive growth...',
      requirements: 'MBA preferred, 4+ years in marketing',
      postedDate: '2024-11-20',
      applications: 28
    },
  ])

  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [selectedJob, setSelectedJob] = useState<any>(null)
  const [newJob, setNewJob] = useState({
    title: '',
    company: '',
    location: '',
    salary: '',
    type: 'Full-time',
    description: '',
    requirements: '',
    status: 'Active'
  })

  const handleAddJob = () => {
    const job = {
      id: jobs.length + 1,
      ...newJob,
      logo: '/placeholder-logo.png',
      postedDate: new Date().toISOString().split('T')[0],
      applications: 0
    }
    setJobs([...jobs, job])
    setShowAddModal(false)
    setNewJob({
      title: '',
      company: '',
      location: '',
      salary: '',
      type: 'Full-time',
      description: '',
      requirements: '',
      status: 'Active'
    })
    alert('Job added successfully!')
  }

  const handleEditJob = () => {
    const updatedJobs = jobs.map(job => 
      job.id === selectedJob.id ? selectedJob : job
    )
    setJobs(updatedJobs)
    setShowEditModal(false)
    setSelectedJob(null)
    alert('Job updated successfully!')
  }

  const handleDeleteJob = (jobId: number) => {
    if (confirm('Are you sure you want to delete this job?')) {
      setJobs(jobs.filter(job => job.id !== jobId))
      alert('Job deleted successfully!')
    }
  }

  const handleToggleStatus = (jobId: number) => {
    const updatedJobs = jobs.map(job => 
      job.id === jobId 
        ? { ...job, status: job.status === 'Active' ? 'Inactive' : 'Active' }
        : job
    )
    setJobs(updatedJobs)
  }

  const activeJobs = jobs.filter(job => job.status === 'Active').length
  const totalApplications = jobs.reduce((sum, job) => sum + job.applications, 0)

  return (
    <>
      <Head>
        <title>Admin Dashboard - AhhChip</title>
      </Head>

      <AdminLayout activePage="dashboard">
        <div style={{ marginBottom: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ margin: 0, fontSize: '1.75rem', fontWeight: 700, color: '#1e293b' }}>Manage Jobs</h1>
          <button 
            onClick={() => setShowAddModal(true)}
            style={{
              padding: '0.75rem 1.5rem',
              background: '#f97316',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
            <i className="fas fa-plus"></i>
            Add New Job
          </button>
        </div>

        {/* Stats Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem', marginBottom: '2rem' }}>
          <div style={{ background: 'white', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div style={{ width: '50px', height: '50px', background: '#fed7aa', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="fas fa-briefcase" style={{ fontSize: '1.5rem', color: '#f97316' }}></i>
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: '2rem', fontWeight: 700, color: '#1e293b' }}>{jobs.length}</h3>
                <p style={{ margin: '0.25rem 0 0 0', color: '#64748b', fontSize: '0.9rem' }}>Total Jobs</p>
              </div>
            </div>
          </div>

          <div style={{ background: 'white', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div style={{ width: '50px', height: '50px', background: '#fed7aa', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="fas fa-eye" style={{ fontSize: '1.5rem', color: '#f97316' }}></i>
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: '2rem', fontWeight: 700, color: '#1e293b' }}>{activeJobs}</h3>
                <p style={{ margin: '0.25rem 0 0 0', color: '#64748b', fontSize: '0.9rem' }}>Active Jobs</p>
              </div>
            </div>
          </div>

          <div style={{ background: 'white', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div style={{ width: '50px', height: '50px', background: '#fed7aa', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="fas fa-users" style={{ fontSize: '1.5rem', color: '#f97316' }}></i>
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: '2rem', fontWeight: 700, color: '#1e293b' }}>{totalApplications}</h3>
                <p style={{ margin: '0.25rem 0 0 0', color: '#64748b', fontSize: '0.9rem' }}>Applications</p>
              </div>
            </div>
          </div>
        </div>

        {/* Jobs Table */}
        <div style={{ background: 'white', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: 600, color: '#374151', fontSize: '0.875rem' }}>Job Title</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: 600, color: '#374151', fontSize: '0.875rem' }}>Company</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: 600, color: '#374151', fontSize: '0.875rem' }}>Location</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: 600, color: '#374151', fontSize: '0.875rem' }}>Salary</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: 600, color: '#374151', fontSize: '0.875rem' }}>Status</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: 600, color: '#374151', fontSize: '0.875rem' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job) => (
                <tr key={job.id} style={{ borderBottom: '1px solid #e5e7eb' }}>
                  <td style={{ padding: '1rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <Image src={job.logo} alt={job.company} width={40} height={40} style={{ borderRadius: '6px' }} />
                      <span style={{ fontWeight: 600, color: '#1e293b' }}>{job.title}</span>
                    </div>
                  </td>
                  <td style={{ padding: '1rem', color: '#64748b' }}>{job.company}</td>
                  <td style={{ padding: '1rem', color: '#64748b' }}>{job.location}</td>
                  <td style={{ padding: '1rem', color: '#10b981', fontWeight: 600 }}>{job.salary}</td>
                  <td style={{ padding: '1rem' }}>
                    <span 
                      onClick={() => handleToggleStatus(job.id)}
                      style={{ 
                        padding: '0.375rem 0.75rem', 
                        background: job.status === 'Active' ? '#dcfce7' : '#fee2e2', 
                        color: job.status === 'Active' ? '#166534' : '#991b1b', 
                        borderRadius: '6px', 
                        fontSize: '0.875rem', 
                        fontWeight: 600,
                        cursor: 'pointer'
                      }}>
                      {job.status}
                    </span>
                  </td>
                  <td style={{ padding: '1rem' }}>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      <button 
                        onClick={() => {
                          setSelectedJob(job)
                          setShowEditModal(true)
                        }}
                        style={{ padding: '0.5rem', background: 'transparent', border: 'none', cursor: 'pointer', color: '#3b82f6' }}
                        title="Edit">
                        <i className="fas fa-edit"></i>
                      </button>
                      <button 
                        onClick={() => handleDeleteJob(job.id)}
                        style={{ padding: '0.5rem', background: 'transparent', border: 'none', cursor: 'pointer', color: '#ef4444' }}
                        title="Delete">
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add Job Modal */}
        {showAddModal && (
          <div className="modal-overlay active" onClick={() => setShowAddModal(false)} style={{ zIndex: 1000 }}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px', maxHeight: '90vh', overflow: 'auto' }}>
              <div className="modal-header">
                <h2>Add New Job</h2>
                <button className="close-btn" onClick={() => setShowAddModal(false)}>&times;</button>
              </div>
              <div style={{ padding: '1.5rem 0' }}>
                <div style={{ display: 'grid', gap: '1rem' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Job Title *</label>
                    <input type="text" value={newJob.title} onChange={(e) => setNewJob({...newJob, title: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Company *</label>
                    <input type="text" value={newJob.company} onChange={(e) => setNewJob({...newJob, company: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Location *</label>
                    <input type="text" value={newJob.location} onChange={(e) => setNewJob({...newJob, location: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Salary Range *</label>
                    <input type="text" value={newJob.salary} onChange={(e) => setNewJob({...newJob, salary: e.target.value})} placeholder="e.g., $80k - $120k" style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Job Type *</label>
                    <select value={newJob.type} onChange={(e) => setNewJob({...newJob, type: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }}>
                      <option>Full-time</option>
                      <option>Part-time</option>
                      <option>Contract</option>
                      <option>Internship</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Description *</label>
                    <textarea value={newJob.description} onChange={(e) => setNewJob({...newJob, description: e.target.value})} rows={4} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px', fontFamily: 'inherit' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Requirements *</label>
                    <textarea value={newJob.requirements} onChange={(e) => setNewJob({...newJob, requirements: e.target.value})} rows={3} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px', fontFamily: 'inherit' }} />
                  </div>
                </div>
              </div>
              <div className="modal-actions">
                <button className="btn-secondary" onClick={() => setShowAddModal(false)}>Cancel</button>
                <button className="btn-primary" onClick={handleAddJob}><i className="fas fa-plus"></i> Add Job</button>
              </div>
            </div>
          </div>
        )}

        {/* Edit Job Modal */}
        {showEditModal && selectedJob && (
          <div className="modal-overlay active" onClick={() => setShowEditModal(false)} style={{ zIndex: 1000 }}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px', maxHeight: '90vh', overflow: 'auto' }}>
              <div className="modal-header">
                <h2>Edit Job</h2>
                <button className="close-btn" onClick={() => setShowEditModal(false)}>&times;</button>
              </div>
              <div style={{ padding: '1.5rem 0' }}>
                <div style={{ display: 'grid', gap: '1rem' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Job Title *</label>
                    <input type="text" value={selectedJob.title} onChange={(e) => setSelectedJob({...selectedJob, title: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Company *</label>
                    <input type="text" value={selectedJob.company} onChange={(e) => setSelectedJob({...selectedJob, company: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Location *</label>
                    <input type="text" value={selectedJob.location} onChange={(e) => setSelectedJob({...selectedJob, location: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Salary Range *</label>
                    <input type="text" value={selectedJob.salary} onChange={(e) => setSelectedJob({...selectedJob, salary: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Job Type *</label>
                    <select value={selectedJob.type} onChange={(e) => setSelectedJob({...selectedJob, type: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }}>
                      <option>Full-time</option>
                      <option>Part-time</option>
                      <option>Contract</option>
                      <option>Internship</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Description *</label>
                    <textarea value={selectedJob.description} onChange={(e) => setSelectedJob({...selectedJob, description: e.target.value})} rows={4} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px', fontFamily: 'inherit' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Requirements *</label>
                    <textarea value={selectedJob.requirements} onChange={(e) => setSelectedJob({...selectedJob, requirements: e.target.value})} rows={3} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px', fontFamily: 'inherit' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>Status</label>
                    <select value={selectedJob.status} onChange={(e) => setSelectedJob({...selectedJob, status: e.target.value})} style={{ width: '100%', padding: '0.75rem', border: '1px solid #d1d5db', borderRadius: '8px' }}>
                      <option>Active</option>
                      <option>Inactive</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="modal-actions">
                <button className="btn-secondary" onClick={() => setShowEditModal(false)}>Cancel</button>
                <button className="btn-primary" onClick={handleEditJob}><i className="fas fa-save"></i> Save Changes</button>
              </div>
            </div>
          </div>
        )}
      </AdminLayout>
    </>
  )
}
