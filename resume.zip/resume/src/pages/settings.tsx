import { useState } from 'react'
import Layout from '@/components/Layout'
import Head from 'next/head'
import { useRouter } from 'next/router'

export default function Settings() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState('account')
  const [formData, setFormData] = useState({
    fullname: 'John Doe',
    email: 'john@example.com',
    phone: '+855 12 345 678',
    location: 'Phnom Penh, Cambodia',
    emailNotifications: true,
    jobAlerts: true,
    profilePublic: false
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    })
  }

  const handleSave = () => {
    alert('Settings saved successfully!')
  }

  const handleDeleteAccount = () => {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      alert('Account deleted. Redirecting...')
      router.push('/')
    }
  }

  return (
    <>
      <Head>
        <title>Settings - AhhChip</title>
      </Head>
      <Layout>
        <div className="info-page">
          <div className="info-container" style={{ maxWidth: '1000px' }}>
            <h1>Settings</h1>
            <p className="info-subtitle">Manage your account settings and preferences</p>
            
            {/* Settings Tabs */}
            <div className="settings-tabs" style={{ 
              display: 'flex', 
              gap: '1rem', 
              borderBottom: '2px solid var(--light-bg)',
              marginTop: '2rem',
              marginBottom: '2rem'
            }}>
              <button
                onClick={() => setActiveTab('account')}
                style={{
                  padding: '1rem 1.5rem',
                  background: 'none',
                  border: 'none',
                  borderBottom: activeTab === 'account' ? '3px solid var(--primary-orange)' : '3px solid transparent',
                  color: activeTab === 'account' ? 'var(--primary-orange)' : 'var(--text-color)',
                  fontWeight: activeTab === 'account' ? 600 : 400,
                  cursor: 'pointer',
                  fontSize: '1rem'
                }}
              >
                <i className="fas fa-user"></i> Account
              </button>
              <button
                onClick={() => setActiveTab('notifications')}
                style={{
                  padding: '1rem 1.5rem',
                  background: 'none',
                  border: 'none',
                  borderBottom: activeTab === 'notifications' ? '3px solid var(--primary-orange)' : '3px solid transparent',
                  color: activeTab === 'notifications' ? 'var(--primary-orange)' : 'var(--text-color)',
                  fontWeight: activeTab === 'notifications' ? 600 : 400,
                  cursor: 'pointer',
                  fontSize: '1rem'
                }}
              >
                <i className="fas fa-bell"></i> Notifications
              </button>
            </div>

            {/* Account Settings */}
            {activeTab === 'account' && (
              <div className="settings-content">
                <div style={{ background: 'white', padding: '2rem', borderRadius: '12px', marginBottom: '2rem', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
                  <h2 style={{ marginBottom: '1.5rem' }}>Account Information</h2>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    <div>
                      <label htmlFor="fullname" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>
                        Full Name
                      </label>
                      <input
                        type="text"
                        id="fullname"
                        name="fullname"
                        value={formData.fullname}
                        onChange={handleChange}
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                          fontSize: '1rem'
                        }}
                      />
                    </div>

                    <div>
                      <label htmlFor="email" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                          fontSize: '1rem'
                        }}
                      />
                    </div>

                    <div>
                      <label htmlFor="phone" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                          fontSize: '1rem'
                        }}
                      />
                    </div>

                    <div>
                      <label htmlFor="location" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>
                        Location
                      </label>
                      <input
                        type="text"
                        id="location"
                        name="location"
                        value={formData.location}
                        onChange={handleChange}
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                          fontSize: '1rem'
                        }}
                      />
                    </div>
                  </div>

                  <button onClick={handleSave} className="btn-primary" style={{ marginTop: '1.5rem' }}>
                    <i className="fas fa-save"></i> Save Changes
                  </button>
                </div>

                {/* Change Password */}
                <div style={{ background: 'white', padding: '2rem', borderRadius: '12px', marginBottom: '2rem', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
                  <h2 style={{ marginBottom: '1.5rem' }}>Change Password</h2>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    <div>
                      <label htmlFor="currentPassword" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>
                        Current Password
                      </label>
                      <input
                        type="password"
                        id="currentPassword"
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                          fontSize: '1rem'
                        }}
                      />
                    </div>

                    <div>
                      <label htmlFor="newPassword" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>
                        New Password
                      </label>
                      <input
                        type="password"
                        id="newPassword"
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                          fontSize: '1rem'
                        }}
                      />
                    </div>

                    <div>
                      <label htmlFor="confirmPassword" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600 }}>
                        Confirm New Password
                      </label>
                      <input
                        type="password"
                        id="confirmPassword"
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                          fontSize: '1rem'
                        }}
                      />
                    </div>
                  </div>

                  <button onClick={() => alert('Password changed successfully!')} className="btn-primary" style={{ marginTop: '1.5rem' }}>
                    <i className="fas fa-key"></i> Update Password
                  </button>
                </div>

                {/* Delete Account - Moved under Change Password */}
                <div style={{ background: 'white', padding: '2rem', borderRadius: '12px', border: '2px solid #ef4444', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginTop: '2rem' }}>
                  <h2 style={{ marginBottom: '1rem', color: '#ef4444' }}>Danger Zone</h2>
                  <p style={{ marginBottom: '1.5rem', color: 'var(--light-text)' }}>
                    Once you delete your account, there is no going back. Please be certain.
                  </p>
                  <button 
                    onClick={handleDeleteAccount}
                    style={{
                      padding: '0.75rem 1.5rem',
                      background: '#ef4444',
                      color: 'white',
                      border: 'none',
                      borderRadius: '8px',
                      cursor: 'pointer',
                      fontSize: '1rem',
                      fontWeight: 600
                    }}
                  >
                    <i className="fas fa-trash"></i> Delete Account
                  </button>
                </div>
              </div>
            )}

            {/* Notification Settings */}
            {activeTab === 'notifications' && (
              <div className="settings-content">
                <div style={{ background: 'white', padding: '2rem', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
                  <h2 style={{ marginBottom: '1.5rem' }}>Notification Preferences</h2>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem', background: 'var(--light-bg)', borderRadius: '8px' }}>
                      <div>
                        <h3 style={{ margin: 0, marginBottom: '0.25rem' }}>Job Notification</h3>
                        <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--light-text)' }}>Get notified when new jobs match your preferences</p>
                      </div>
                      <label className="switch" style={{ position: 'relative', display: 'inline-block', width: '60px', height: '34px' }}>
                        <input
                          type="checkbox"
                          name="jobAlerts"
                          checked={formData.jobAlerts}
                          onChange={handleChange}
                          style={{ opacity: 0, width: 0, height: 0 }}
                        />
                        <span style={{
                          position: 'absolute',
                          cursor: 'pointer',
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          backgroundColor: formData.jobAlerts ? 'var(--primary-orange)' : '#ccc',
                          transition: '0.4s',
                          borderRadius: '34px'
                        }}>
                          <span style={{
                            position: 'absolute',
                            content: '',
                            height: '26px',
                            width: '26px',
                            left: formData.jobAlerts ? '30px' : '4px',
                            bottom: '4px',
                            backgroundColor: 'white',
                            transition: '0.4s',
                            borderRadius: '50%'
                          }}></span>
                        </span>
                      </label>
                    </div>
                  </div>

                  <button onClick={handleSave} className="btn-primary" style={{ marginTop: '1.5rem' }}>
                    <i className="fas fa-save"></i> Save Preferences
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </Layout>
    </>
  )
}
