import Head from 'next/head'
import AdminLayout from '@/components/AdminLayout'

export default function JobCrawler() {
  return (
    <>
      <Head>
        <title>Job Crawler - Admin</title>
      </Head>

      <AdminLayout activePage="crawler">
        <div className="admin-content">
          <div style={{ marginBottom: '2rem' }}>
            <h2 style={{ margin: '0 0 0.5rem 0', color: '#1e293b' }}>
              <i className="fas fa-spider"></i> Job Crawler
            </h2>
            <p style={{ margin: 0, color: '#64748b' }}>
              Automatically crawl and import jobs from external sources
            </p>
          </div>

          <div style={{ display: 'grid', gap: '1.5rem' }}>
            {/* Crawler Status */}
            <div style={{
              padding: '1.5rem',
              background: '#f0f9ff',
              border: '1px solid #bae6fd',
              borderRadius: '8px'
            }}>
              <h3 style={{ margin: '0 0 1rem 0', color: '#0369a1' }}>Crawler Status</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
                <div>
                  <p style={{ margin: 0, color: '#64748b', fontSize: '0.9rem' }}>Status</p>
                  <p style={{ margin: '0.25rem 0 0 0', color: '#10b981', fontWeight: 600, fontSize: '1.1rem' }}>
                    <i className="fas fa-check-circle"></i> Active
                  </p>
                </div>
                <div>
                  <p style={{ margin: 0, color: '#64748b', fontSize: '0.9rem' }}>Last Run</p>
                  <p style={{ margin: '0.25rem 0 0 0', color: '#1e293b', fontWeight: 600 }}>2 hours ago</p>
                </div>
                <div>
                  <p style={{ margin: 0, color: '#64748b', fontSize: '0.9rem' }}>Jobs Crawled Today</p>
                  <p style={{ margin: '0.25rem 0 0 0', color: '#1e293b', fontWeight: 600 }}>127</p>
                </div>
              </div>
            </div>

            {/* Crawler Sources */}
            <div>
              <h3 style={{ margin: '0 0 1rem 0', color: '#1e293b' }}>Crawler Sources</h3>
              <div style={{ display: 'grid', gap: '1rem' }}>
                {[
                  { name: 'Indeed', url: 'indeed.com', status: 'active', jobs: 45 },
                  { name: 'LinkedIn', url: 'linkedin.com', status: 'active', jobs: 38 },
                  { name: 'Glassdoor', url: 'glassdoor.com', status: 'active', jobs: 27 },
                  { name: 'Monster', url: 'monster.com', status: 'inactive', jobs: 0 },
                ].map((source, index) => (
                  <div key={index} style={{
                    padding: '1rem',
                    background: 'white',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <div>
                      <h4 style={{ margin: 0, color: '#1e293b' }}>{source.name}</h4>
                      <p style={{ margin: '0.25rem 0 0 0', color: '#64748b', fontSize: '0.9rem' }}>{source.url}</p>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{ textAlign: 'right' }}>
                        <p style={{ margin: 0, color: '#64748b', fontSize: '0.85rem' }}>Jobs Today</p>
                        <p style={{ margin: '0.25rem 0 0 0', color: '#1e293b', fontWeight: 600 }}>{source.jobs}</p>
                      </div>
                      <span style={{
                        padding: '0.5rem 1rem',
                        background: source.status === 'active' ? '#dcfce7' : '#fee2e2',
                        color: source.status === 'active' ? '#166534' : '#991b1b',
                        borderRadius: '20px',
                        fontSize: '0.85rem',
                        fontWeight: 600
                      }}>
                        {source.status === 'active' ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: '1rem' }}>
              <button style={{
                padding: '0.875rem 1.5rem',
                background: '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                fontWeight: 600
              }}>
                <i className="fas fa-play"></i> Run Crawler Now
              </button>
              <button style={{
                padding: '0.875rem 1.5rem',
                background: 'white',
                color: '#64748b',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                cursor: 'pointer',
                fontWeight: 600
              }}>
                <i className="fas fa-cog"></i> Configure Sources
              </button>
            </div>
          </div>
        </div>
      </AdminLayout>
    </>
  )
}
