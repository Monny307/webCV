import { useEffect, useState, useRef } from 'react'
import Layout from '@/components/Layout'
import { Job } from '@/lib/types'
import Head from 'next/head'
import Link from 'next/link'

export default function Home() {
  const [activeSection, setActiveSection] = useState('jobs')
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    
    // Check authentication status - SSR safe
    if (typeof window !== 'undefined') {
      const currentUser = localStorage.getItem('currentUser')
      setIsLoggedIn(!!currentUser)
    }

    // Load jobs
    fetchJobs()

    // Function to handle hash changes
    const handleHashChange = () => {
      const hash = window.location.hash.substring(1)
      if (hash && (hash === 'cv' || hash === 'jobs' || hash === 'my-jobs' || hash === 'profile')) {
        setActiveSection(hash)
        // Scroll to top when switching sections
        window.scrollTo({ top: 0, behavior: 'smooth' })
      } else if (!hash) {
        setActiveSection('jobs')
      }
    }

    // Initial hash check with small delay to ensure DOM is ready
    setTimeout(handleHashChange, 100)

    // Listen for hash changes
    window.addEventListener('hashchange', handleHashChange, false)
    
    // Also listen for clicks on hash links
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const link = target.closest('a[href^="#"]')
      if (link) {
        setTimeout(handleHashChange, 50)
      }
    }
    
    document.addEventListener('click', handleClick, false)
    
    return () => {
      window.removeEventListener('hashchange', handleHashChange, false)
      document.removeEventListener('click', handleClick, false)
    }
  }, [])

  const fetchJobs = async () => {
    try {
      const response = await fetch('/api/jobs')
      const data = await response.json()
      if (data.success) {
        setJobs(data.jobs)
      }
    } catch (error) {
      console.error('Error fetching jobs:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Head>
        <title>AhhChip - Smart Resume Tracker</title>
      </Head>
      <Layout>
        {/* CV Section */}
        <section id="cv" className={`section ${activeSection === 'cv' ? 'active' : ''}`} style={{ display: activeSection === 'cv' ? 'block' : 'none', minHeight: '100vh' }}>
          <div className="section-container">
            <CVSection />
          </div>
        </section>

        {/* Jobs Section */}
        <section id="jobs" className={`section ${activeSection === 'jobs' ? 'active' : ''}`} style={{ display: activeSection === 'jobs' ? 'block' : 'none', minHeight: '100vh' }}>
          <JobsSection jobs={jobs} loading={loading} />
        </section>

        {/* My Jobs Section */}
        <section id="my-jobs" className={`section ${activeSection === 'my-jobs' ? 'active' : ''}`} style={{ display: activeSection === 'my-jobs' ? 'block' : 'none', minHeight: '100vh' }}>
          <MyJobsSection />
        </section>

        {/* Profile Section */}
        <section id="profile" className={`section ${activeSection === 'profile' ? 'active' : ''}`} style={{ display: activeSection === 'profile' ? 'block' : 'none', minHeight: '100vh' }}>
          <ProfileSection />
        </section>
      </Layout>
    </>
  )
}

// CV Section Component
function CVSection() {
  const [showCVMenu, setShowCVMenu] = useState<number | null>(null)
  const [showCVViewer, setShowCVViewer] = useState(false)
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [showMessageModal, setShowMessageModal] = useState(false)
  const [messageContent, setMessageContent] = useState('')
  const [selectedCV, setSelectedCV] = useState<string | null>(null)
  const [profilePhoto, setProfilePhoto] = useState('/noprofile.png')
  const [editingSection, setEditingSection] = useState<string | null>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [mounted, setMounted] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const cvUploadRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setMounted(true)
    
    if (typeof window !== 'undefined') {
      const currentUser = localStorage.getItem('currentUser')
      setIsLoggedIn(!!currentUser)
    }
  }, [])

  const showMessage = (message: string) => {
    setMessageContent(message)
    setShowMessageModal(true)
  }

  const [profileData, setProfileData] = useState({
    fullName: 'Not provided',
    email: 'Not provided',
    phone: 'Not provided',
    gender: 'Not provided',
    dateOfBirth: 'Not provided',
    location: 'Not provided',
    education: 'No education information provided',
    workExperience: 'No work experience provided',
    skills: 'No skills provided',
    languages: 'No languages provided',
    certifications: 'No certifications provided',
    professionalSummary: 'No professional summary provided'
  })

  const pastCVs = [
    { id: 1, name: 'Resume_2024.pdf', date: 'Dec 1, 2024', isCurrent: true },
    { id: 2, name: 'Resume_2023.pdf', date: 'Nov 15, 2023', isCurrent: false }
  ]

  const handlePhotoClick = () => {
    fileInputRef.current?.click()
  }

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfilePhoto(reader.result as string)
      }
      reader.readAsDataURL(file)
      showMessage('Profile photo updated successfully!')
    }
  }

  const handleSetAsCurrent = (id: number) => {
    showMessage(`CV ${id} set as current! ML model will analyze automatically...`)
    setShowCVMenu(null)
  }

  const handleViewCV = (cvName: string) => {
    setSelectedCV(cvName)
    setShowCVViewer(true)
    setShowCVMenu(null)
  }

  const handleDeleteCV = (id: number) => {
    if (confirm('Are you sure you want to delete this CV?')) {
      showMessage(`CV ${id} deleted!`)
      setShowCVMenu(null)
    }
  }

  const handleDownloadCV = () => {
    showMessage('Downloading CV...')
  }

  const handleEditSection = (section: string) => {
    setEditingSection(section)
  }

  const handleSaveSection = () => {
    showMessage('Profile information saved successfully!')
    setEditingSection(null)
  }

  const handleUploadCV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const fileType = file.name.split('.').pop()?.toLowerCase()
      if (fileType === 'pdf' || fileType === 'doc' || fileType === 'docx') {
        showMessage(`CV "${file.name}" uploaded successfully! ML model will analyze automatically...`)
        setShowUploadModal(false)
      } else {
        showMessage('Please upload a PDF, DOC, or DOCX file.')
      }
    }
  }

  const scrollToProfileInfo = () => {
    const profileSection = document.querySelector('.profile-fields')
    if (profileSection) {
      profileSection.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  if (!isLoggedIn) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 2rem', maxWidth: '600px', margin: '0 auto' }}>
        <i className="fas fa-lock" style={{ fontSize: '4rem', color: '#f97316', marginBottom: '1.5rem', display: 'block' }}></i>
        <h2 style={{ fontSize: '2rem', marginBottom: '1rem', color: '#1e293b' }}>Sign In Required</h2>
        <p style={{ color: '#64748b', marginBottom: '2rem', fontSize: '1.1rem' }}>
          Please sign in to upload and manage your CV, and access personalized job recommendations.
        </p>
        <Link href="/login">
          <button className="btn-primary" style={{ padding: '1rem 2rem', fontSize: '1.1rem' }}>
            <i className="fas fa-sign-in-alt"></i> Sign In Now
          </button>
        </Link>
      </div>
    )
  }

  return (
    <>
      <aside className="cv-sidebar">
        <h3>Past CVs</h3>
        <div className="cv-list">
          {pastCVs.map((cv) => (
            <div key={cv.id} className={`cv-item ${cv.isCurrent ? 'active' : ''}`} style={{ position: 'relative' }}>
              <div className="cv-icon"><i className="fas fa-file-pdf"></i></div>
              <div className="cv-info">
                <h4>{cv.name}</h4>
                <span className="cv-date">{cv.date}</span>
              </div>
              <button
                onClick={() => setShowCVMenu(showCVMenu === cv.id ? null : cv.id)}
                style={{
                  position: 'absolute',
                  right: '1rem',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '1.2rem',
                  color: 'var(--light-text)',
                  padding: '0.5rem'
                }}
              >
                <i className="fas fa-ellipsis-v"></i>
              </button>
              {showCVMenu === cv.id && (
                <div style={{
                  position: 'absolute',
                  right: '1rem',
                  top: '100%',
                  background: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                  minWidth: '180px',
                  zIndex: 100,
                  overflow: 'hidden',
                  marginTop: '0.5rem'
                }}>
                  {!cv.isCurrent && (
                    <button
                      onClick={() => handleSetAsCurrent(cv.id)}
                      style={{
                        width: '100%',
                        padding: '0.75rem 1rem',
                        background: 'none',
                        border: 'none',
                        textAlign: 'left',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        fontSize: '0.95rem',
                        transition: 'background 0.2s'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.background = '#f9fafb'}
                      onMouseLeave={(e) => e.currentTarget.style.background = 'none'}
                    >
                      <i className="fas fa-check-circle" style={{ color: 'var(--primary-orange)' }}></i>
                      Set as Current
                    </button>
                  )}
                  <button
                    onClick={() => handleViewCV(cv.name)}
                    style={{
                      width: '100%',
                      padding: '0.75rem 1rem',
                      background: 'none',
                      border: 'none',
                      textAlign: 'left',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.75rem',
                      fontSize: '0.95rem',
                      transition: 'background 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = '#f9fafb'}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'none'}
                  >
                    <i className="fas fa-eye" style={{ color: 'var(--primary-orange)' }}></i>
                    View CV
                  </button>
                  <button
                    onClick={() => handleDeleteCV(cv.id)}
                    style={{
                      width: '100%',
                      padding: '0.75rem 1rem',
                      background: 'none',
                      border: 'none',
                      textAlign: 'left',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.75rem',
                      fontSize: '0.95rem',
                      color: '#ef4444',
                      transition: 'background 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = '#fef2f2'}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'none'}
                  >
                    <i className="fas fa-trash"></i>
                    Delete
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </aside>

      <div className="cv-main">
        <div className="cv-hero">
          <div className="cv-header">
            <div className="cv-title-section">
              <h2>Current Active CV</h2>
              <div className="cv-meta">
                <span className="cv-name">Resume_2024.pdf</span>
                <span className="cv-upload-date">Uploaded: Dec 1, 2024</span>
                <span className="cv-status completed">Completed</span>
              </div>
            </div>
            <div className="cv-actions">
              <button className="btn-action" onClick={scrollToProfileInfo}><i className="fas fa-edit"></i> Edit Profile</button>
              <button className="btn-action" onClick={() => handleViewCV('Resume_2024.pdf')}><i className="fas fa-eye"></i> View Full CV</button>
            </div>
          </div>
        </div>

        <div className="profile-fields">
          <h3>Profile Information</h3>
          
          <div className="profile-header-section">
            <div className="profile-image-container">
              <img src={profilePhoto} alt="Profile" className="profile-image" />
              <button className="btn-edit-image" onClick={handlePhotoClick}>
                <i className="fas fa-camera"></i>
              </button>
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*"
                onChange={handlePhotoChange}
                style={{ display: 'none' }}
              />
            </div>
          </div>

          <div className="field-group">
            <div className="field-header">
              <h4><i className="fas fa-user"></i> Personal Details</h4>
              <button className="btn-edit-field" onClick={() => handleEditSection('personal')}>
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <div className="field-content">
              {editingSection === 'personal' ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  <input type="text" placeholder="Full Name" defaultValue={profileData.fullName} style={{ padding: '0.5rem', border: '1px solid #e5e7eb', borderRadius: '6px' }} />
                  <input type="email" placeholder="Email" defaultValue={profileData.email} style={{ padding: '0.5rem', border: '1px solid #e5e7eb', borderRadius: '6px' }} />
                  <input type="tel" placeholder="Phone" defaultValue={profileData.phone} style={{ padding: '0.5rem', border: '1px solid #e5e7eb', borderRadius: '6px' }} />
                  <input type="text" placeholder="Gender" defaultValue={profileData.gender} style={{ padding: '0.5rem', border: '1px solid #e5e7eb', borderRadius: '6px' }} />
                  <input type="date" placeholder="Date of Birth" defaultValue={profileData.dateOfBirth} style={{ padding: '0.5rem', border: '1px solid #e5e7eb', borderRadius: '6px' }} />
                  <input type="text" placeholder="Location" defaultValue={profileData.location} style={{ padding: '0.5rem', border: '1px solid #e5e7eb', borderRadius: '6px' }} />
                  <button className="btn-primary" onClick={handleSaveSection} style={{ alignSelf: 'flex-start' }}>Save</button>
                </div>
              ) : (
                <div className="info-display">
                  <div className="info-row">
                    <span className="info-label">Full Name:</span>
                    <span className="info-value">{profileData.fullName}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Email:</span>
                    <span className="info-value">{profileData.email}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Phone:</span>
                    <span className="info-value">{profileData.phone}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Gender:</span>
                    <span className="info-value">{profileData.gender}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Date of Birth:</span>
                    <span className="info-value">{profileData.dateOfBirth}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Location:</span>
                    <span className="info-value">{profileData.location}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="field-group">
            <div className="field-header">
              <h4><i className="fas fa-graduation-cap"></i> Education</h4>
              <button className="btn-edit-field" onClick={() => handleEditSection('education')}>
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <div className="field-content">
              {editingSection === 'education' ? (
                <div>
                  <textarea placeholder="Add education information..." defaultValue={profileData.education} style={{ width: '100%', minHeight: '100px', padding: '0.75rem', border: '1px solid #e5e7eb', borderRadius: '6px', fontFamily: 'inherit' }} />
                  <button className="btn-primary" onClick={handleSaveSection} style={{ marginTop: '1rem' }}>Save</button>
                </div>
              ) : (
                <p style={{ color: 'var(--light-text)', fontStyle: 'italic' }}>{profileData.education}</p>
              )}
            </div>
          </div>

          <div className="field-group">
            <div className="field-header">
              <h4><i className="fas fa-briefcase"></i> Work Experience</h4>
              <button className="btn-edit-field" onClick={() => handleEditSection('work')}>
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <div className="field-content">
              {editingSection === 'work' ? (
                <div>
                  <textarea placeholder="Add work experience..." defaultValue={profileData.workExperience} style={{ width: '100%', minHeight: '100px', padding: '0.75rem', border: '1px solid #e5e7eb', borderRadius: '6px', fontFamily: 'inherit' }} />
                  <button className="btn-primary" onClick={handleSaveSection} style={{ marginTop: '1rem' }}>Save</button>
                </div>
              ) : (
                <p style={{ color: 'var(--light-text)', fontStyle: 'italic' }}>{profileData.workExperience}</p>
              )}
            </div>
          </div>

          <div className="field-group">
            <div className="field-header">
              <h4><i className="fas fa-tools"></i> Skills</h4>
              <button className="btn-edit-field" onClick={() => handleEditSection('skills')}>
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <div className="field-content">
              {editingSection === 'skills' ? (
                <div>
                  <textarea placeholder="Add skills..." defaultValue={profileData.skills} style={{ width: '100%', minHeight: '100px', padding: '0.75rem', border: '1px solid #e5e7eb', borderRadius: '6px', fontFamily: 'inherit' }} />
                  <button className="btn-primary" onClick={handleSaveSection} style={{ marginTop: '1rem' }}>Save</button>
                </div>
              ) : (
                <p style={{ color: 'var(--light-text)', fontStyle: 'italic' }}>{profileData.skills}</p>
              )}
            </div>
          </div>

          <div className="field-group">
            <div className="field-header">
              <h4><i className="fas fa-language"></i> Languages</h4>
              <button className="btn-edit-field" onClick={() => handleEditSection('languages')}>
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <div className="field-content">
              {editingSection === 'languages' ? (
                <div>
                  <textarea placeholder="Add languages..." defaultValue={profileData.languages} style={{ width: '100%', minHeight: '100px', padding: '0.75rem', border: '1px solid #e5e7eb', borderRadius: '6px', fontFamily: 'inherit' }} />
                  <button className="btn-primary" onClick={handleSaveSection} style={{ marginTop: '1rem' }}>Save</button>
                </div>
              ) : (
                <p style={{ color: 'var(--light-text)', fontStyle: 'italic' }}>{profileData.languages}</p>
              )}
            </div>
          </div>

          <div className="field-group">
            <div className="field-header">
              <h4><i className="fas fa-certificate"></i> Certifications</h4>
              <button className="btn-edit-field" onClick={() => handleEditSection('certifications')}>
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <div className="field-content">
              {editingSection === 'certifications' ? (
                <div>
                  <textarea placeholder="Add certifications..." defaultValue={profileData.certifications} style={{ width: '100%', minHeight: '100px', padding: '0.75rem', border: '1px solid #e5e7eb', borderRadius: '6px', fontFamily: 'inherit' }} />
                  <button className="btn-primary" onClick={handleSaveSection} style={{ marginTop: '1rem' }}>Save</button>
                </div>
              ) : (
                <p style={{ color: 'var(--light-text)', fontStyle: 'italic' }}>{profileData.certifications}</p>
              )}
            </div>
          </div>

          <div className="field-group">
            <div className="field-header">
              <h4><i className="fas fa-file-alt"></i> Professional Summary</h4>
              <button className="btn-edit-field" onClick={() => handleEditSection('summary')}>
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <div className="field-content">
              {editingSection === 'summary' ? (
                <div>
                  <textarea placeholder="Add professional summary..." defaultValue={profileData.professionalSummary} style={{ width: '100%', minHeight: '100px', padding: '0.75rem', border: '1px solid #e5e7eb', borderRadius: '6px', fontFamily: 'inherit' }} />
                  <button className="btn-primary" onClick={handleSaveSection} style={{ marginTop: '1rem' }}>Save</button>
                </div>
              ) : (
                <p style={{ color: 'var(--light-text)', fontStyle: 'italic' }}>{profileData.professionalSummary}</p>
              )}
            </div>
          </div>
        </div>
      </div>


      {/* Upload CV Modal */}
      {showUploadModal && (
        <div className="modal-overlay active" onClick={() => setShowUploadModal(false)} style={{ zIndex: 1000 }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '500px' }}>
            <div className="modal-header">
              <h2>Upload New CV</h2>
              <button className="close-btn" onClick={() => setShowUploadModal(false)}>&times;</button>
            </div>
            
            <div style={{ padding: '1rem 0' }}>
              <div style={{ 
                border: '2px dashed #d1d5db', 
                borderRadius: '12px', 
                padding: '3rem 2rem', 
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onClick={() => cvUploadRef.current?.click()}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'var(--primary-orange)'
                e.currentTarget.style.background = 'rgba(255, 140, 66, 0.05)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = '#d1d5db'
                e.currentTarget.style.background = 'transparent'
              }}
              >
                <i className="fas fa-cloud-upload-alt" style={{ fontSize: '3rem', color: 'var(--primary-orange)', marginBottom: '1rem' }}></i>
                <p style={{ marginBottom: '0.5rem', fontWeight: 600 }}>Click to upload or drag and drop</p>
                <p style={{ fontSize: '0.9rem', color: 'var(--light-text)' }}>Supported formats: PDF, DOC, DOCX</p>
                <p style={{ fontSize: '0.85rem', color: 'var(--light-text)', marginTop: '0.5rem' }}>Maximum file size: 10MB</p>
              </div>
              <input 
                ref={cvUploadRef}
                type="file" 
                accept=".pdf,.doc,.docx"
                onChange={handleUploadCV}
                style={{ display: 'none' }}
              />
            </div>
            
            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setShowUploadModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CV Viewer Modal */}
      {showCVViewer && (
        <div className="modal-overlay active" onClick={() => setShowCVViewer(false)} style={{ zIndex: 1000 }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '900px', maxHeight: '90vh' }}>
            <div className="modal-header">
              <h2>View CV: {selectedCV}</h2>
              <button className="close-btn" onClick={() => setShowCVViewer(false)}>&times;</button>
            </div>
            
            <div style={{ padding: '2rem', background: '#f9fafb', borderRadius: '8px', minHeight: '500px', maxHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'auto' }}>
              <div style={{ textAlign: 'center' }}>
                <i className="fas fa-file-pdf" style={{ fontSize: '4rem', color: 'var(--primary-orange)', marginBottom: '1rem' }}></i>
                <p style={{ color: 'var(--light-text)' }}>CV Preview: {selectedCV}</p>
                <p style={{ color: 'var(--light-text)', fontSize: '0.9rem' }}>Full PDF viewer would be integrated here</p>
              </div>
            </div>
            
            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setShowCVViewer(false)}>
                <i className="fas fa-times"></i> Close
              </button>
              <button className="btn-primary" onClick={handleDownloadCV}>
                <i className="fas fa-download"></i> Download
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message Modal */}
      {showMessageModal && (
        <div className="modal-overlay active" onClick={() => setShowMessageModal(false)} style={{ zIndex: 1001 }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '450px' }}>
            <div className="modal-header">
              <h2>Notification</h2>
              <button className="close-btn" onClick={() => setShowMessageModal(false)}>&times;</button>
            </div>
            
            <div style={{ padding: '1.5rem 0' }}>
              <p style={{ fontSize: '1rem', lineHeight: '1.6', color: 'var(--dark-text)' }}>{messageContent}</p>
            </div>
            
            <div className="modal-actions">
              <button className="btn-primary" onClick={() => setShowMessageModal(false)} style={{ width: '100%', justifyContent: 'center' }}>
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

// Jobs Section Component
function JobsSection({ jobs, loading }: { jobs: Job[], loading: boolean }) {
  const [showFilterModal, setShowFilterModal] = useState(false)
  const [activeFilterType, setActiveFilterType] = useState<string | null>(null)

  const scrollToSection = (sectionId: string) => {
    setTimeout(() => {
      const element = document.getElementById(sectionId)
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }
    }, 100)
  }

  return (
    <div className="jobs-container">
      <div className="jobs-hero-banner">
        <div className="hero-overlay"></div>
        <div className="hero-banner-content">
          <h1>Find Your Perfect Job</h1>
          
          <div className="hero-search-box">
            <div className="search-input-wrapper">
              <i className="fas fa-search"></i>
              <input type="text" placeholder="Job title, keywords, or company..." />
            </div>
            <button className="btn-hero-search">
              <i className="fas fa-search"></i>
              Search
            </button>
          </div>

          <div className="filter-bar-container">
            <div className="filter-chips">
              <button className="filter-chip" onClick={() => {
                setActiveFilterType('category')
                setShowFilterModal(true)
              }}>
                <i className="fas fa-briefcase"></i>
                <span>Career Category</span>
                <i className="fas fa-chevron-down"></i>
              </button>
              <button className="filter-chip" onClick={() => {
                setActiveFilterType('location')
                setShowFilterModal(true)
              }}>
                <i className="fas fa-map-marker-alt"></i>
                <span>Location</span>
                <i className="fas fa-chevron-down"></i>
              </button>
              <button className="filter-chip" onClick={() => {
                setActiveFilterType('salary')
                setShowFilterModal(true)
              }}>
                <i className="fas fa-dollar-sign"></i>
                <span>Salary Range</span>
                <i className="fas fa-chevron-down"></i>
              </button>
              <button className="filter-chip" onClick={() => {
                setActiveFilterType('jobType')
                setShowFilterModal(true)
              }}>
                <i className="fas fa-clock"></i>
                <span>Job Type</span>
                <i className="fas fa-chevron-down"></i>
              </button>
            </div>
            <button className="btn-filter-icon" onClick={() => {
              setActiveFilterType('all')
              setShowFilterModal(true)
            }}>
              <i className="fas fa-sliders-h"></i>
              <span>All Filters</span>
            </button>
          </div>

          <div className="quick-filters"></div>
        </div>
      </div>

      <h2 style={{ 
        textAlign: 'center', 
        marginTop: '3rem', 
        marginBottom: '2rem',
        fontSize: '2rem',
        fontWeight: 700,
        color: '#1e293b'
      }}>
        Available Jobs
      </h2>

      <div className="jobs-list">
        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem 2rem' }}>
            <i className="fas fa-spinner fa-spin" style={{ fontSize: '3rem', color: '#f97316', marginBottom: '1rem' }}></i>
            <p>Loading jobs...</p>
          </div>
        ) : (
          jobs.map((job) => (
            <Link key={job.id} href={`/jobs/${job.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
              <div className="job-card" style={{ cursor: 'pointer' }}>
                <div className="job-header">
                  <div className="job-company-logo">
                    {job.logo ? (
                      <img src={job.logo} alt={job.company} />
                    ) : (
                      <i className="fas fa-building"></i>
                    )}
                  </div>
                  <div className="job-header-content">
                    <div className="job-header-top">
                      <p className="company-name">{job.company}</p>
                      <button className="btn-save-job" onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        alert('Job saved!')
                      }}>
                        <i className="far fa-heart"></i>
                      </button>
                    </div>
                  </div>
                </div>
                
                <h3 className="job-title">{job.title}</h3>
                <p className="job-salary">{job.salary}</p>
                
                <div className="job-info-row">
                  <span className="job-info-item">
                    <i className="fas fa-map-marker-alt"></i>
                    {job.location}
                  </span>
                  <span className="job-info-item">
                    <i className="fas fa-map-marker-alt"></i>
                    Phnom Penh
                  </span>
                </div>
                
                <div className="job-info-row">
                  <span className="job-info-item">
                    <i className="fas fa-briefcase"></i>
                    {job.jobType}
                  </span>
                  <span className="job-info-item">
                    <i className="fas fa-calendar"></i>
                    {job.postedDate ? new Date(job.postedDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '15 Jan 2026'}
                  </span>
                </div>
                
                <button className="btn-view-more">View More</button>
              </div>
            </Link>
          ))
        )}
      </div>

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="modal-overlay active" onClick={() => setShowFilterModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{
            maxWidth: '480px',
            width: '90%',
            maxHeight: '85vh',
            background: 'white',
            borderRadius: '12px',
            padding: '0',
            position: 'relative',
            display: 'flex',
            flexDirection: 'column'
          }}>
            {/* Header */}
            <div style={{
              padding: '1.5rem 2rem',
              borderBottom: '1px solid #e5e7eb',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <h2 style={{ margin: 0, fontSize: '1.5rem', fontWeight: 700, color: '#1f2937' }}>
                Filter Jobs
              </h2>
              <button 
                onClick={() => setShowFilterModal(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  fontSize: '1.5rem',
                  cursor: 'pointer',
                  color: '#6b7280',
                  padding: 0,
                  width: '32px',
                  height: '32px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            
            {/* Scrollable Content */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '1.5rem 2rem'
            }}>
              {activeFilterType === 'category' ? (
                /* Career Category Section Only */
                <div id="filter-category" style={{ marginBottom: '2rem' }}>
                  <h3 style={{ 
                    fontSize: '1rem', 
                    fontWeight: 700, 
                    color: '#1f2937',
                    marginBottom: '1rem',
                    display: 'flex',
                    alignItems: 'center'
                  }}>
                    <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                    Career Category
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                    {[
                      'Technology & IT',
                      'Marketing & Sales',
                      'Finance & Accounting',
                      'Healthcare',
                      'Education',
                      'Engineering',
                      'Hospitality & Tourism',
                      'Construction'
                    ].map(cat => (
                      <label key={cat} style={{ 
                        display: 'flex', 
                        alignItems: 'center',
                        cursor: 'pointer',
                        fontSize: '0.95rem',
                        color: '#4b5563'
                      }}>
                        <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                        <span>{cat}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ) : activeFilterType === 'location' ? (
                /* Location Section Only */
                <div id="filter-location" style={{ marginBottom: '2rem' }}>
                  <h3 style={{ 
                    fontSize: '1rem', 
                    fontWeight: 700, 
                    color: '#1f2937',
                    marginBottom: '1rem',
                    display: 'flex',
                    alignItems: 'center'
                  }}>
                    <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                    Location (Province)
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                    {[
                      'Phnom Penh',
                      'Siem Reap',
                      'Battambang',
                      'Sihanoukville',
                      'Kampong Cham',
                      'Kampot',
                      'Remote'
                    ].map(loc => (
                      <label key={loc} style={{ 
                        display: 'flex', 
                        alignItems: 'center',
                        cursor: 'pointer',
                        fontSize: '0.95rem',
                        color: '#4b5563'
                      }}>
                        <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                        <span>{loc}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ) : activeFilterType === 'salary' ? (
                /* Salary Range Section Only */
                <div id="filter-salary" style={{ marginBottom: '2rem' }}>
                  <h3 style={{ 
                    fontSize: '1rem', 
                    fontWeight: 700, 
                    color: '#1f2937',
                    marginBottom: '1rem',
                    display: 'flex',
                    alignItems: 'center'
                  }}>
                    <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                    Salary Range
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                    {[
                      '$500 - $1000',
                      '$1000 - $1500',
                      '$1500 - $2000',
                      '$2000 - $3000',
                      '$3000+'
                    ].map(range => (
                      <label key={range} style={{ 
                        display: 'flex', 
                        alignItems: 'center',
                        cursor: 'pointer',
                        fontSize: '0.95rem',
                        color: '#4b5563'
                      }}>
                        <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                        <span>{range}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ) : activeFilterType === 'jobType' ? (
                /* Job Type Section Only */
                <div id="filter-jobType" style={{ marginBottom: '2rem' }}>
                  <h3 style={{ 
                    fontSize: '1rem', 
                    fontWeight: 700, 
                    color: '#1f2937',
                    marginBottom: '1rem',
                    display: 'flex',
                    alignItems: 'center'
                  }}>
                    <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                    Job Type
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                    {[
                      'Full-time',
                      'Part-time',
                      'Contract',
                      'Internship',
                      'Freelance'
                    ].map(type => (
                      <label key={type} style={{ 
                        display: 'flex', 
                        alignItems: 'center',
                        cursor: 'pointer',
                        fontSize: '0.95rem',
                        color: '#4b5563'
                      }}>
                        <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                        <span>{type}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ) : (
                <>
              {/* Career Category Section */}
              <div id="filter-category" style={{ marginBottom: '2rem' }}>
                <h3 style={{ 
                  fontSize: '1rem', 
                  fontWeight: 700, 
                  color: '#1f2937',
                  marginBottom: '1rem',
                  display: 'flex',
                  alignItems: 'center'
                }}>
                  <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                  Career Category
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                  {[
                    'Technology & IT',
                    'Marketing & Sales',
                    'Finance & Accounting',
                    'Healthcare',
                    'Education',
                    'Engineering',
                    'Hospitality & Tourism',
                    'Construction'
                  ].map(cat => (
                    <label key={cat} style={{ 
                      display: 'flex', 
                      alignItems: 'center',
                      cursor: 'pointer',
                      fontSize: '0.95rem',
                      color: '#4b5563'
                    }}>
                      <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                      <span>{cat}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Location Section */}
              <div id="filter-location" style={{ marginBottom: '2rem' }}>
                <h3 style={{ 
                  fontSize: '1rem', 
                  fontWeight: 700, 
                  color: '#1f2937',
                  marginBottom: '1rem',
                  display: 'flex',
                  alignItems: 'center'
                }}>
                  <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                  Location (Province)
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                  {[
                    'Phnom Penh',
                    'Siem Reap',
                    'Battambang',
                    'Sihanoukville',
                    'Kampong Cham',
                    'Kampot',
                    'Remote'
                  ].map(loc => (
                    <label key={loc} style={{ 
                      display: 'flex', 
                      alignItems: 'center',
                      cursor: 'pointer',
                      fontSize: '0.95rem',
                      color: '#4b5563'
                    }}>
                      <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                      <span>{loc}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Salary Range Section */}
              <div id="filter-salary" style={{ marginBottom: '2rem' }}>
                <h3 style={{ 
                  fontSize: '1rem', 
                  fontWeight: 700, 
                  color: '#1f2937',
                  marginBottom: '1rem',
                  display: 'flex',
                  alignItems: 'center'
                }}>
                  <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                  Salary Range
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                  {[
                    '$500 - $1000',
                    '$1000 - $1500',
                    '$1500 - $2000',
                    '$2000 - $3000',
                    '$3000+'
                  ].map(range => (
                    <label key={range} style={{ 
                      display: 'flex', 
                      alignItems: 'center',
                      cursor: 'pointer',
                      fontSize: '0.95rem',
                      color: '#4b5563'
                    }}>
                      <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                      <span>{range}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Job Type Section */}
              <div id="filter-jobType" style={{ marginBottom: '1rem' }}>
                <h3 style={{ 
                  fontSize: '1rem', 
                  fontWeight: 700, 
                  color: '#1f2937',
                  marginBottom: '1rem',
                  display: 'flex',
                  alignItems: 'center'
                }}>
                  <input type="checkbox" style={{ marginRight: '0.75rem', width: '18px', height: '18px' }} />
                  Job Type
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '2rem' }}>
                  {[
                    'Full-time',
                    'Part-time',
                    'Contract',
                    'Internship',
                    'Freelance'
                  ].map(type => (
                    <label key={type} style={{ 
                      display: 'flex', 
                      alignItems: 'center',
                      cursor: 'pointer',
                      fontSize: '0.95rem',
                      color: '#4b5563'
                    }}>
                      <input type="checkbox" style={{ marginRight: '0.75rem', width: '16px', height: '16px' }} />
                      <span>{type}</span>
                    </label>
                  ))}
                </div>
              </div>
                </>
              )}
            </div>
            
            {/* Footer */}
            <div style={{
              padding: '1.5rem 2rem',
              borderTop: '1px solid #e5e7eb',
              display: 'flex',
              gap: '1rem'
            }}>
              <button 
                onClick={() => setShowFilterModal(false)}
                style={{
                  flex: 1,
                  padding: '0.875rem 1.5rem',
                  background: 'white',
                  border: '1px solid #d1d5db',
                  borderRadius: '8px',
                  fontSize: '1rem',
                  fontWeight: 600,
                  color: '#374151',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
              >
                Reset All
              </button>
              <button 
                onClick={() => {
                  alert('Filters applied! (This is a demo)')
                  setShowFilterModal(false)
                }}
                style={{
                  flex: 1,
                  padding: '0.875rem 1.5rem',
                  background: 'var(--primary-orange)',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '1rem',
                  fontWeight: 600,
                  color: 'white',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
              >
                Confirm Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// My Jobs Section Component with Working Tabs
function MyJobsSection() {
  const [activeTab, setActiveTab] = useState('recommended')
  const [showAppDetailModal, setShowAppDetailModal] = useState(false)
  const [showAddAppModal, setShowAddAppModal] = useState(false)
  const [showUploadCVModal, setShowUploadCVModal] = useState(false)
  const [uploadOption, setUploadOption] = useState<'upload' | 'past' | null>(null)
  const [selectedApplication, setSelectedApplication] = useState<any>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [newAppData, setNewAppData] = useState({
    title: '',
    company: '',
    location: '',
    salary: '',
    status: 'Applied',
    notes: ''
  })
  const [pastCVs] = useState([
    { id: 1, name: 'Resume_2024.pdf', date: 'Dec 1, 2024', isCurrent: true },
    { id: 2, name: 'CV_Software_Engineer.pdf', date: 'Nov 15, 2024', isCurrent: false },
    { id: 3, name: 'Resume_Updated.pdf', date: 'Oct 20, 2024', isCurrent: false }
  ])
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  // Check auth status and load data accordingly
  useEffect(() => {
    setMounted(true)
    
    if (typeof window !== 'undefined') {
      const currentUser = localStorage.getItem('currentUser')
      const loggedIn = !!currentUser
      setIsLoggedIn(loggedIn)
      
      // Clear data if not logged in
      if (!loggedIn) {
        setSavedJobs([])
        setRecommendedJobs([])
        setApplications([])
      } else {
        // Load user's data from localStorage or API
        const savedData = localStorage.getItem('userSavedJobs')
        const recommendedData = localStorage.getItem('userRecommendedJobs')
        const applicationsData = localStorage.getItem('userApplications')
        
        if (savedData) setSavedJobs(JSON.parse(savedData))
        else setSavedJobs([
          { id: 1, company: 'Tech Solutions Inc', title: 'Senior Frontend Developer', salary: '$1,500 - $2,000', location: 'Phnom Penh', type: 'Full-time', postedDate: '2 days ago', logo: '', match: '92%' },
          { id: 2, company: 'Digital Agency Co', title: 'UI/UX Designer', salary: '$1,200 - $1,800', location: 'Siem Reap', type: 'Full-time', postedDate: '5 days ago', logo: '', match: '88%' }
        ])
        if (recommendedData) setRecommendedJobs(JSON.parse(recommendedData))
        else setRecommendedJobs([
          { id: 1, company: 'Tech Corp', title: 'Full Stack Developer', salary: '$1,500 - $2,500', location: 'Phnom Penh', type: 'Full-time', postedDate: '1 day ago', logo: '', match: '95%', accuracy: '95%' },
          { id: 2, company: 'StartupXYZ', title: 'React Developer', salary: '$1,200 - $1,800', location: 'Remote', type: 'Full-time', postedDate: '3 days ago', logo: '', match: '90%', accuracy: '90%' },
          { id: 3, company: 'Global Tech', title: 'Node.js Developer', salary: '$1,800 - $2,200', location: 'Phnom Penh', type: 'Full-time', postedDate: '4 days ago', logo: '', match: '88%', accuracy: '88%' }
        ])
        if (applicationsData) setApplications(JSON.parse(applicationsData))
      }
    }
  }, [])
  
  const [savedJobs, setSavedJobs] = useState<any[]>([])
  const [recommendedJobs, setRecommendedJobs] = useState<any[]>([])
  const [applications, setApplications] = useState<any[]>([])

  const handleUnsaveJob = (jobId: number) => {
    setSavedJobs(savedJobs.filter(job => job.id !== jobId))
  }

  const handleRefresh = () => {
    alert('Refreshing jobs...')
  }

  const handleAddApplication = () => {
    if (!newAppData.title || !newAppData.company) {
      alert('Please fill in required fields')
      return
    }
    const newApp = {
      id: applications.length + 1,
      title: newAppData.title,
      company: newAppData.company,
      location: newAppData.location || 'Not specified',
      salary: newAppData.salary || 'Not specified',
      status: newAppData.status,
      appliedDate: 'Just now',
      notes: newAppData.notes || 'No notes'
    }
    setApplications([...applications, newApp])
    setShowAddAppModal(false)
    setNewAppData({
      title: '',
      company: '',
      location: '',
      salary: '',
      status: 'Applied',
      notes: ''
    })
    alert('Application added successfully!')
  }

  const handleViewAppDetail = (app: any) => {
    setSelectedApplication(app)
    setShowAppDetailModal(true)
  }

  const handleStatusChange = (newStatus: string) => {
    if (selectedApplication) {
      const updatedApplications = applications.map(app => 
        app.id === selectedApplication.id ? { ...app, status: newStatus } : app
      )
      setApplications(updatedApplications)
      setSelectedApplication({ ...selectedApplication, status: newStatus })
      alert(`Application status updated to: ${newStatus}`)
    }
  }

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'Applied': return '#3b82f6'
      case 'Reviewed': return '#f59e0b'
      case 'Interview': return '#10b981'
      case 'Offer': return '#8b5cf6'
      case 'Rejected': return '#ef4444'
      default: return '#6b7280'
    }
  }

  return (
    <div className="my-jobs-container">
      <h1>My Jobs</h1>
      
      <div className="tabs">
        <button 
          className={`tab-btn ${activeTab === 'recommended' ? 'active' : ''}`}
          onClick={() => setActiveTab('recommended')}
        >
          <i className="fas fa-star"></i> Recommended ({recommendedJobs.length})
        </button>
        <button 
          className={`tab-btn ${activeTab === 'saved' ? 'active' : ''}`}
          onClick={() => setActiveTab('saved')}
        >
          <i className="fas fa-heart"></i> Saved Jobs ({savedJobs.length})
        </button>
        <button 
          className={`tab-btn ${activeTab === 'applications' ? 'active' : ''}`}
          onClick={() => setActiveTab('applications')}
        >
          <i className="fas fa-paper-plane"></i> Applications ({applications.length})
        </button>
      </div>

      {activeTab === 'recommended' && (
        <div className="tab-content active">
          <div className="tab-header">
            <h2>Recommended Jobs</h2>
            <button className="btn-refresh" onClick={handleRefresh}>
              <i className="fas fa-sync"></i> Refresh
            </button>
          </div>
          
          {/* Upload CV Button and Keywords */}
          <div style={{ marginBottom: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <button 
              onClick={() => setShowUploadCVModal(true)}
              className="btn-primary"
              style={{ 
                alignSelf: 'flex-start',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.75rem 1.5rem'
              }}
            >
              <i className="fas fa-upload"></i> Upload CV
            </button>
            
            {/* Keywords Display */}
            <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <h3 style={{ margin: '0 0 0.5rem 0', fontSize: '0.9rem', fontWeight: 600, color: '#64748b' }}>
                Recommendation Keywords:
              </h3>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {recommendedJobs.length > 0 ? (
                  ['JavaScript', 'React', 'Node.js', 'TypeScript', 'Full Stack'].map((keyword, idx) => (
                    <span 
                      key={idx}
                      style={{
                        padding: '0.375rem 0.75rem',
                        background: 'white',
                        border: '1px solid #e2e8f0',
                        borderRadius: '6px',
                        fontSize: '0.875rem',
                        color: '#1e293b',
                        fontWeight: 500
                      }}
                    >
                      {keyword}
                    </span>
                  ))
                ) : (
                  <span style={{ color: '#64748b', fontSize: '0.875rem' }}>No match - Upload CV to get recommendations</span>
                )}
              </div>
            </div>
          </div>

          <div className="jobs-list">
            {!isLoggedIn ? (
              <div style={{ textAlign: 'center', padding: '4rem 2rem', background: 'white', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
                <i className="fas fa-lock" style={{ fontSize: '4rem', color: '#f97316', marginBottom: '1.5rem', display: 'block' }}></i>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '1rem', color: '#1e293b' }}>Sign In Required</h3>
                <p style={{ color: '#64748b', marginBottom: '2rem', fontSize: '1.1rem' }}>
                  Please sign in to view personalized job recommendations based on your CV and preferences.
                </p>
                <Link href="/login">
                  <button className="btn-primary" style={{ padding: '1rem 2rem', fontSize: '1.1rem' }}>
                    <i className="fas fa-sign-in-alt"></i> Sign In Now
                  </button>
                </Link>
              </div>
            ) : recommendedJobs.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--light-text)' }}>
                <i className="fas fa-star" style={{ fontSize: '3rem', marginBottom: '1rem', display: 'block', color: '#f97316' }}></i>
                <p>No recommended jobs yet. Upload your CV to get personalized recommendations!</p>
              </div>
            ) : recommendedJobs.map((job) => (
              <Link key={job.id} href={`/jobs/${job.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                <div className="job-card" style={{ marginBottom: '1rem', cursor: 'pointer' }}>
                  <div className="job-header" style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
                    <img 
                      src={job.logo} 
                      alt={job.company}
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        borderRadius: '8px',
                        objectFit: 'cover',
                        flexShrink: 0
                      }}
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                        (e.target as HTMLImageElement).nextElementSibling?.setAttribute('style', 'display: flex');
                      }}
                    />
                    <div style={{ 
                      width: '80px', 
                      height: '80px', 
                      borderRadius: '8px',
                      background: '#f3f4f6',
                      display: 'none',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0
                    }}>
                      <i className="fas fa-building" style={{ fontSize: '2rem', color: '#9ca3af' }}></i>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '0.5rem' }}>
                        <div style={{ flex: 1 }}>
                          <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 600, color: '#1e293b' }}>{job.company}</h3>
                          <span style={{ 
                            background: '#10b981', 
                            color: 'white', 
                            padding: '0.2rem 0.6rem', 
                            borderRadius: '12px', 
                            fontSize: '0.7rem',
                            fontWeight: 600,
                            display: 'inline-block',
                            marginTop: '0.25rem'
                          }}>
                            {job.accuracy || job.match || '85%'} Accuracy
                          </span>
                        </div>
                        <button 
                          className="btn-save-job"
                          onClick={(e) => {
                            e.preventDefault()
                            e.stopPropagation()
                            alert('Job saved!')
                          }}
                          style={{ fontSize: '1.5rem', color: '#e5e7eb', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
                        >
                          <i className="far fa-heart"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                  <h2 style={{ margin: '0 0 0.5rem 0', fontSize: '1.25rem', fontWeight: 600, color: '#1e293b' }}>{job.title}</h2>
                  <p style={{ color: 'var(--primary-orange)', fontWeight: 600, fontSize: '1rem', margin: '0 0 0.75rem 0' }}>
                    {job.salary}
                  </p>
                  <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap', marginBottom: '0.5rem' }}>
                    <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <i className="fas fa-map-marker-alt" style={{ color: 'var(--primary-orange)' }}></i> {job.location}
                    </span>
                    <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <i className="fas fa-map-marker-alt" style={{ color: 'var(--primary-orange)' }}></i> Phnom Penh
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
                    <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <i className="fas fa-briefcase" style={{ color: 'var(--primary-orange)' }}></i> {job.type}
                    </span>
                    <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <i className="fas fa-calendar" style={{ color: 'var(--primary-orange)' }}></i> {job.postedDate}
                    </span>
                  </div>
                  <button style={{
                    width: '100%',
                    padding: '0.875rem',
                    background: 'var(--primary-orange)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '8px',
                    fontWeight: 600,
                    fontSize: '1rem',
                    cursor: 'pointer'
                  }}>
                    View More
                  </button>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'saved' && (
        <div className="tab-content active">
          <div className="tab-header">
            <h2>Saved Jobs</h2>
            <button className="btn-refresh" onClick={handleRefresh}>
              <i className="fas fa-sync"></i> Refresh
            </button>
          </div>
          

          <div className="jobs-list">
            {!isLoggedIn ? (
              <div style={{ textAlign: 'center', padding: '4rem 2rem', background: 'white', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
                <i className="fas fa-lock" style={{ fontSize: '4rem', color: '#ef4444', marginBottom: '1.5rem', display: 'block' }}></i>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '1rem', color: '#1e293b' }}>Sign In Required</h3>
                <p style={{ color: '#64748b', marginBottom: '2rem', fontSize: '1.1rem' }}>
                  Please sign in to save jobs and access them later.
                </p>
                <Link href="/login">
                  <button className="btn-primary" style={{ padding: '1rem 2rem', fontSize: '1.1rem' }}>
                    <i className="fas fa-sign-in-alt"></i> Sign In Now
                  </button>
                </Link>
              </div>
            ) : savedJobs.length > 0 ? (
              savedJobs.map((job) => (
                <Link key={job.id} href={`/jobs/${job.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                  <div className="job-card" style={{ marginBottom: '1rem', cursor: 'pointer' }}>
                    <div className="job-header" style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
                      <img 
                        src={job.logo} 
                        alt={job.company}
                        style={{ 
                          width: '80px', 
                          height: '80px', 
                          borderRadius: '8px',
                          objectFit: 'cover',
                          flexShrink: 0
                        }}
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                          (e.target as HTMLImageElement).nextElementSibling?.setAttribute('style', 'display: flex');
                        }}
                      />
                      <div style={{ 
                        width: '80px', 
                        height: '80px', 
                        borderRadius: '8px',
                        background: '#f3f4f6',
                        display: 'none',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0
                      }}>
                        <i className="fas fa-building" style={{ fontSize: '2rem', color: '#9ca3af' }}></i>
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                          <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 600, color: '#1e293b' }}>{job.company}</h3>
                          <button 
                            className="btn-save-job" 
                            onClick={(e) => {
                              e.preventDefault()
                              e.stopPropagation()
                              handleUnsaveJob(job.id)
                            }}
                            style={{ fontSize: '1.5rem', color: '#ef4444', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
                          >
                            <i className="fas fa-heart"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                    <h2 style={{ margin: '0 0 0.5rem 0', fontSize: '1.25rem', fontWeight: 600, color: '#1e293b' }}>{job.title}</h2>
                    <p style={{ color: 'var(--primary-orange)', fontWeight: 600, fontSize: '1rem', margin: '0 0 0.75rem 0' }}>
                      {job.salary}
                    </p>
                    <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap', marginBottom: '0.5rem' }}>
                      <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <i className="fas fa-map-marker-alt" style={{ color: 'var(--primary-orange)' }}></i> {job.location}
                      </span>
                      <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <i className="fas fa-map-marker-alt" style={{ color: 'var(--primary-orange)' }}></i> Phnom Penh
                      </span>
                    </div>
                    <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
                      <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <i className="fas fa-briefcase" style={{ color: 'var(--primary-orange)' }}></i> {job.type}
                      </span>
                      <span style={{ fontSize: '0.9rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <i className="fas fa-calendar" style={{ color: 'var(--primary-orange)' }}></i> {job.postedDate}
                      </span>
                    </div>
                    <button style={{
                      width: '100%',
                      padding: '0.875rem',
                      background: 'var(--primary-orange)',
                      color: 'white',
                      border: 'none',
                      borderRadius: '8px',
                      fontWeight: 600,
                      fontSize: '1rem',
                      cursor: 'pointer'
                    }}>
                      View More
                    </button>
                  </div>
                </Link>
              ))
            ) : (
              <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--light-text)' }}>
                <i className="far fa-heart" style={{ fontSize: '3rem', marginBottom: '1rem', display: 'block' }}></i>
                <p>No saved jobs yet. Start saving jobs you're interested in!</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'applications' && (
        <div className="tab-content active">
          <div className="tab-header">
            <h2>My Applications</h2>
            <div style={{ display: 'flex', gap: '0.75rem' }}>
              {isLoggedIn && (
                <button 
                  className="btn-primary" 
                  onClick={() => setShowAddAppModal(true)}
                  style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
                >
                  <i className="fas fa-plus"></i> Add Application
                </button>
              )}
              <button className="btn-refresh" onClick={handleRefresh}>
                <i className="fas fa-sync"></i> Refresh
              </button>
            </div>
          </div>
          

          {!isLoggedIn ? (
            <div style={{ textAlign: 'center', padding: '4rem 2rem', background: 'white', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginTop: '2rem' }}>
              <i className="fas fa-lock" style={{ fontSize: '4rem', color: '#3b82f6', marginBottom: '1.5rem', display: 'block' }}></i>
              <h3 style={{ fontSize: '1.5rem', marginBottom: '1rem', color: '#1e293b' }}>Sign In Required</h3>
              <p style={{ color: '#64748b', marginBottom: '2rem', fontSize: '1.1rem' }}>
                Please sign in to track your job applications and manage your application pipeline.
              </p>
              <Link href="/login">
                <button className="btn-primary" style={{ padding: '1rem 2rem', fontSize: '1.1rem' }}>
                  <i className="fas fa-sign-in-alt"></i> Sign In Now
                </button>
              </Link>
            </div>
          ) : applications.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '4rem 2rem', background: 'white', borderRadius: '12px', marginTop: '2rem' }}>
              <i className="fas fa-paper-plane" style={{ fontSize: '3rem', color: '#3b82f6', marginBottom: '1rem', display: 'block' }}></i>
              <h3 style={{ fontSize: '1.25rem', marginBottom: '0.5rem', color: '#1e293b' }}>No Applications Yet</h3>
              <p style={{ color: '#64748b', marginBottom: '2rem' }}>
                Start tracking your job applications by clicking the "+ Add Application" button above.
              </p>
            </div>
          ) : (
            <>
          {/* Kanban Board - 3 Columns */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
            {/* Column 1: Applied */}
            <div style={{ background: '#eff6ff', borderRadius: '12px', padding: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '0.75rem', borderBottom: '2px solid #3b82f6' }}>
                <h3 style={{ margin: 0, color: '#1e40af', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <i className="fas fa-paper-plane"></i> Applied
                </h3>
                <span style={{ background: '#3b82f6', color: 'white', padding: '0.25rem 0.75rem', borderRadius: '20px', fontSize: '0.85rem', fontWeight: 600 }}>
                  {applications.filter(a => a.status === 'Applied').length}
                </span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {applications.filter(a => a.status === 'Applied').map((app) => (
                  <div key={app.id} style={{ background: 'white', padding: '1rem', borderRadius: '8px', border: '1px solid #bfdbfe', cursor: 'pointer' }} onClick={() => handleViewAppDetail(app)}>
                    <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '0.95rem', color: '#1e293b' }}>{app.title}</h4>
                    <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.85rem', color: '#64748b' }}>{app.company}</p>
                    <p style={{ margin: 0, fontSize: '0.75rem', color: '#94a3b8' }}>
                      <i className="fas fa-clock"></i> {app.appliedDate}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 2: Reviewed */}
            <div style={{ background: '#fffbeb', borderRadius: '12px', padding: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '0.75rem', borderBottom: '2px solid #f59e0b' }}>
                <h3 style={{ margin: 0, color: '#92400e', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <i className="fas fa-eye"></i> Reviewed
                </h3>
                <span style={{ background: '#f59e0b', color: 'white', padding: '0.25rem 0.75rem', borderRadius: '20px', fontSize: '0.85rem', fontWeight: 600 }}>
                  {applications.filter(a => a.status === 'Reviewed').length}
                </span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {applications.filter(a => a.status === 'Reviewed').map((app) => (
                  <div key={app.id} style={{ background: 'white', padding: '1rem', borderRadius: '8px', border: '1px solid #fde68a', cursor: 'pointer' }} onClick={() => handleViewAppDetail(app)}>
                    <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '0.95rem', color: '#1e293b' }}>{app.title}</h4>
                    <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.85rem', color: '#64748b' }}>{app.company}</p>
                    <p style={{ margin: 0, fontSize: '0.75rem', color: '#94a3b8' }}>
                      <i className="fas fa-clock"></i> {app.appliedDate}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 3: Interview */}
            <div style={{ background: '#f0fdf4', borderRadius: '12px', padding: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '0.75rem', borderBottom: '2px solid #10b981' }}>
                <h3 style={{ margin: 0, color: '#065f46', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <i className="fas fa-user-tie"></i> Interview
                </h3>
                <span style={{ background: '#10b981', color: 'white', padding: '0.25rem 0.75rem', borderRadius: '20px', fontSize: '0.85rem', fontWeight: 600 }}>
                  {applications.filter(a => a.status === 'Interview').length}
                </span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {applications.filter(a => a.status === 'Interview').map((app) => (
                  <div key={app.id} style={{ background: 'white', padding: '1rem', borderRadius: '8px', border: '1px solid #a7f3d0', cursor: 'pointer' }} onClick={() => handleViewAppDetail(app)}>
                    <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '0.95rem', color: '#1e293b' }}>{app.title}</h4>
                    <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.85rem', color: '#64748b' }}>{app.company}</p>
                    <p style={{ margin: 0, fontSize: '0.75rem', color: '#94a3b8' }}>
                      <i className="fas fa-clock"></i> {app.appliedDate}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Other Statuses (Offer, Rejected, etc.) */}
          {applications.filter(a => !['Applied', 'Reviewed', 'Interview'].includes(a.status)).length > 0 && (
            <div style={{ marginTop: '2rem' }}>
              <h3 style={{ marginBottom: '1rem', color: '#475569' }}>
                <i className="fas fa-list"></i> Other Statuses
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1rem' }}>
                {applications.filter(a => !['Applied', 'Reviewed', 'Interview'].includes(a.status)).map((app) => (
                  <div 
                    key={app.id} 
                    style={{ 
                      background: 'white', 
                      padding: '1.25rem', 
                      borderRadius: '12px', 
                      border: `2px solid ${getStatusColor(app.status)}`,
                      cursor: 'pointer'
                    }}
                    onClick={() => handleViewAppDetail(app)}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '0.75rem' }}>
                      <h4 style={{ margin: 0, fontSize: '1rem', color: '#1e293b' }}>{app.title}</h4>
                      <span style={{ 
                        background: getStatusColor(app.status), 
                        color: 'white', 
                        padding: '0.25rem 0.75rem', 
                        borderRadius: '20px', 
                        fontSize: '0.75rem',
                        fontWeight: 600
                      }}>
                        {app.status}
                      </span>
                    </div>
                    <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.9rem', color: '#64748b' }}>{app.company}</p>
                    <p style={{ margin: 0, fontSize: '0.8rem', color: '#94a3b8' }}>
                      <i className="fas fa-clock"></i> {app.appliedDate}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
            </>
          )}
        </div>
      )}

      {/* Application Detail Modal with Enhanced Features */}
      {showAppDetailModal && selectedApplication && (
        <div className="modal-overlay active" onClick={() => setShowAppDetailModal(false)} style={{ zIndex: 1001 }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '700px', maxHeight: '90vh', overflow: 'auto' }}>
            <div className="modal-header">
              <h2>Application Details</h2>
              <button className="close-btn" onClick={() => setShowAppDetailModal(false)}>&times;</button>
            </div>
            
            <div style={{ padding: '1.5rem 0' }}>
              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '1rem' }}>
                  <div>
                    <h3 style={{ margin: '0 0 0.5rem 0', fontSize: '1.5rem' }}>{selectedApplication.title}</h3>
                    <p style={{ margin: 0, fontSize: '1.1rem', color: '#64748b' }}>{selectedApplication.company}</p>
                  </div>
                  <span style={{ 
                    background: getStatusColor(selectedApplication.status), 
                    color: 'white', 
                    padding: '0.5rem 1rem', 
                    borderRadius: '20px',
                    fontWeight: 600
                  }}>
                    {selectedApplication.status}
                  </span>
                </div>
              </div>

              <div style={{ display: 'grid', gap: '1rem' }}>
                {/* Status Category Selector */}
                <div style={{ padding: '1rem', background: '#fef3c7', borderRadius: '8px', border: '1px solid #fde68a' }}>
                  <p style={{ margin: '0 0 0.75rem 0', fontSize: '0.85rem', color: '#92400e', fontWeight: 600 }}>
                    <i className="fas fa-tasks"></i> Update Status
                  </p>
                  <select
                    value={selectedApplication.status}
                    onChange={(e) => handleStatusChange(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.75rem',
                      border: '1px solid #fde68a',
                      borderRadius: '8px',
                      fontSize: '1rem',
                      background: 'white',
                      fontWeight: 600,
                      color: '#92400e',
                      cursor: 'pointer'
                    }}
                  >
                    <option value="Applied">Applied</option>
                    <option value="Reviewed">Reviewed</option>
                    <option value="Interview">Interview</option>
                    <option value="Offer">Offer</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                  <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.75rem', color: '#92400e' }}>
                    Select a status to move this application to the corresponding column
                  </p>
                </div>

                <div style={{ padding: '1rem', background: '#f8fafc', borderRadius: '8px' }}>
                  <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Location</p>
                  <p style={{ margin: 0, fontSize: '1rem' }}>
                    <i className="fas fa-map-marker-alt" style={{ color: 'var(--primary-orange)' }}></i> {selectedApplication.location}
                  </p>
                </div>

                <div style={{ padding: '1rem', background: '#f8fafc', borderRadius: '8px' }}>
                  <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Salary Range</p>
                  <p style={{ margin: 0, fontSize: '1rem', color: 'var(--primary-orange)', fontWeight: 600 }}>
                    <i className="fas fa-dollar-sign"></i> {selectedApplication.salary}
                  </p>
                </div>

                <div style={{ padding: '1rem', background: '#f8fafc', borderRadius: '8px' }}>
                  <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Applied Date</p>
                  <p style={{ margin: 0, fontSize: '1rem' }}>
                    <i className="fas fa-calendar"></i> {selectedApplication.appliedDate}
                  </p>
                </div>

                {/* Interview Calendar */}
                <div style={{ padding: '1rem', background: '#f0f9ff', borderRadius: '8px', border: '1px solid #bae6fd' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                    <p style={{ margin: 0, fontSize: '0.85rem', color: '#0369a1', fontWeight: 600 }}>
                      <i className="fas fa-calendar-alt"></i> Interview Schedule
                    </p>
                    <button style={{ 
                      background: '#0ea5e9', 
                      color: 'white', 
                      border: 'none', 
                      padding: '0.25rem 0.75rem', 
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      cursor: 'pointer'
                    }}>
                      <i className="fas fa-plus"></i> Add
                    </button>
                  </div>
                  <input 
                    type="datetime-local" 
                    style={{ 
                      width: '100%', 
                      padding: '0.5rem', 
                      border: '1px solid #bae6fd', 
                      borderRadius: '6px',
                      fontSize: '0.9rem'
                    }}
                  />
                </div>

                {/* Reminders */}
                <div style={{ padding: '1rem', background: '#fef3c7', borderRadius: '8px', border: '1px solid #fde68a' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                    <p style={{ margin: 0, fontSize: '0.85rem', color: '#92400e', fontWeight: 600 }}>
                      <i className="fas fa-bell"></i> Reminders
                    </p>
                    <button style={{ 
                      background: '#f59e0b', 
                      color: 'white', 
                      border: 'none', 
                      padding: '0.25rem 0.75rem', 
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      cursor: 'pointer'
                    }}>
                      <i className="fas fa-plus"></i> Add
                    </button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', background: 'white', borderRadius: '6px' }}>
                      <input type="checkbox" />
                      <span style={{ fontSize: '0.9rem' }}>Follow up on application status</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', background: 'white', borderRadius: '6px' }}>
                      <input type="checkbox" />
                      <span style={{ fontSize: '0.9rem' }}>Prepare for interview</span>
                    </div>
                  </div>
                </div>

                {/* Notes Section */}
                <div style={{ padding: '1rem', background: '#f8fafc', borderRadius: '8px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                    <p style={{ margin: 0, fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>
                      <i className="fas fa-sticky-note"></i> Notes
                    </p>
                    <button style={{ 
                      background: '#64748b', 
                      color: 'white', 
                      border: 'none', 
                      padding: '0.25rem 0.75rem', 
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      cursor: 'pointer'
                    }}>
                      <i className="fas fa-edit"></i> Edit
                    </button>
                  </div>
                  <textarea 
                    defaultValue={selectedApplication.notes}
                    rows={4}
                    style={{ 
                      width: '100%', 
                      padding: '0.75rem', 
                      border: '1px solid #e2e8f0', 
                      borderRadius: '6px',
                      fontSize: '0.9rem',
                      fontFamily: 'inherit',
                      resize: 'vertical'
                    }}
                  />
                </div>

                {/* Additional Actions */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                  <button style={{
                    padding: '0.75rem',
                    background: '#f0fdf4',
                    border: '1px solid #86efac',
                    borderRadius: '8px',
                    color: '#166534',
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.5rem'
                  }}>
                    <i className="fas fa-file-pdf"></i> Download CV
                  </button>
                  <button style={{
                    padding: '0.75rem',
                    background: '#fef2f2',
                    border: '1px solid #fca5a5',
                    borderRadius: '8px',
                    color: '#991b1b',
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.5rem'
                  }}>
                    <i className="fas fa-trash"></i> Withdraw
                  </button>
                </div>
              </div>
            </div>
            
            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setShowAppDetailModal(false)}>
                Close
              </button>
              <button className="btn-primary">
                <i className="fas fa-external-link-alt"></i> View Job Posting
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Application Modal */}
      {showAddAppModal && (
        <div className="modal-overlay active" onClick={() => setShowAddAppModal(false)} style={{ zIndex: 1002 }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px', maxHeight: '90vh', overflow: 'auto' }}>
            <div className="modal-header">
              <h2>Add Application</h2>
              <button className="close-btn" onClick={() => setShowAddAppModal(false)}>&times;</button>
            </div>
            
            <div style={{ padding: '1.5rem 0' }}>
              <div className="form-group" style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#374151' }}>
                  Job Title <span style={{ color: '#ef4444' }}>*</span>
                </label>
                <input
                  type="text"
                  value={newAppData.title}
                  onChange={(e) => setNewAppData({...newAppData, title: e.target.value})}
                  placeholder="e.g., Senior Software Engineer"
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '1rem'
                  }}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#374151' }}>
                  Company <span style={{ color: '#ef4444' }}>*</span>
                </label>
                <input
                  type="text"
                  value={newAppData.company}
                  onChange={(e) => setNewAppData({...newAppData, company: e.target.value})}
                  placeholder="e.g., Tech Corp Inc."
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '1rem'
                  }}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#374151' }}>
                  Location
                </label>
                <input
                  type="text"
                  value={newAppData.location}
                  onChange={(e) => setNewAppData({...newAppData, location: e.target.value})}
                  placeholder="e.g., Phnom Penh"
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '1rem'
                  }}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#374151' }}>
                  Salary Range
                </label>
                <input
                  type="text"
                  value={newAppData.salary}
                  onChange={(e) => setNewAppData({...newAppData, salary: e.target.value})}
                  placeholder="e.g., $1000-1500"
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '1rem'
                  }}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#374151' }}>
                  Status <span style={{ color: '#ef4444' }}>*</span>
                </label>
                <select
                  value={newAppData.status}
                  onChange={(e) => setNewAppData({...newAppData, status: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '1rem',
                    background: 'white'
                  }}
                >
                  <option value="Applied">Applied</option>
                  <option value="Reviewed">Reviewed</option>
                  <option value="Interview">Interview</option>
                  <option value="Offer">Offer</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div className="form-group">
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#374151' }}>
                  Notes
                </label>
                <textarea
                  value={newAppData.notes}
                  onChange={(e) => setNewAppData({...newAppData, notes: e.target.value})}
                  placeholder="Add any notes about this application..."
                  rows={4}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '1rem',
                    fontFamily: 'inherit',
                    resize: 'vertical'
                  }}
                />
              </div>
            </div>
            
            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setShowAddAppModal(false)}>
                Cancel
              </button>
              <button className="btn-primary" onClick={handleAddApplication}>
                <i className="fas fa-plus"></i> Add Application
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload CV Modal */}
      {showUploadCVModal && (
        <div className="modal-overlay active" onClick={() => {
          setShowUploadCVModal(false)
          setUploadOption(null)
        }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px' }}>
            <div className="modal-header">
              <h2>Upload CV</h2>
              <button className="close-btn" onClick={() => {
                setShowUploadCVModal(false)
                setUploadOption(null)
              }}>&times;</button>
            </div>
            
            {!uploadOption ? (
              <div style={{ padding: '2rem' }}>
                <p style={{ marginBottom: '1.5rem', color: '#64748b' }}>Choose how you want to upload your CV:</p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  <button
                    onClick={() => setUploadOption('upload')}
                    style={{
                      padding: '1rem',
                      background: '#f8fafc',
                      border: '2px solid #e2e8f0',
                      borderRadius: '8px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '1rem',
                      fontSize: '1rem',
                      fontWeight: 600,
                      color: '#1e293b'
                    }}
                  >
                    <i className="fas fa-upload" style={{ fontSize: '1.5rem', color: 'var(--primary-orange)' }}></i>
                    <div style={{ textAlign: 'left' }}>
                      <div>Upload New CV</div>
                      <div style={{ fontSize: '0.875rem', fontWeight: 400, color: '#64748b', marginTop: '0.25rem' }}>
                        Upload a new CV file from your device
                      </div>
                    </div>
                  </button>
                  <button
                    onClick={() => setUploadOption('past')}
                    style={{
                      padding: '1rem',
                      background: '#f8fafc',
                      border: '2px solid #e2e8f0',
                      borderRadius: '8px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '1rem',
                      fontSize: '1rem',
                      fontWeight: 600,
                      color: '#1e293b'
                    }}
                  >
                    <i className="fas fa-file-alt" style={{ fontSize: '1.5rem', color: 'var(--primary-orange)' }}></i>
                    <div style={{ textAlign: 'left' }}>
                      <div>Choose from Past CVs</div>
                      <div style={{ fontSize: '0.875rem', fontWeight: 400, color: '#64748b', marginTop: '0.25rem' }}>
                        Select from your previously uploaded CVs
                      </div>
                    </div>
                  </button>
                </div>
              </div>
            ) : uploadOption === 'upload' ? (
              <div style={{ padding: '2rem' }}>
                <div style={{ 
                  border: '2px dashed #d1d5db', 
                  borderRadius: '8px', 
                  padding: '3rem 2rem',
                  textAlign: 'center',
                  cursor: 'pointer',
                  marginBottom: '1.5rem'
                }}
                onClick={() => fileInputRef.current?.click()}
                >
                  <i className="fas fa-cloud-upload-alt" style={{ fontSize: '3rem', color: '#9ca3af', marginBottom: '1rem', display: 'block' }}></i>
                  <p style={{ color: '#64748b', marginBottom: '0.5rem' }}>Click to upload or drag and drop</p>
                  <p style={{ fontSize: '0.875rem', color: '#94a3b8' }}>PDF, DOC, DOCX (MAX. 5MB)</p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx"
                  style={{ display: 'none' }}
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) {
                      alert(`CV uploaded: ${file.name}`)
                      setShowUploadCVModal(false)
                      setUploadOption(null)
                    }
                  }}
                />
                <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-end' }}>
                  <button className="btn-secondary" onClick={() => setUploadOption(null)}>
                    Back
                  </button>
                </div>
              </div>
            ) : (
              <div style={{ padding: '2rem' }}>
                <p style={{ marginBottom: '1rem', color: '#64748b' }}>Select a past CV to use:</p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.5rem' }}>
                  {pastCVs.map((cv) => (
                    <div
                      key={cv.id}
                      onClick={() => {
                        alert(`CV selected: ${cv.name}`)
                        setShowUploadCVModal(false)
                        setUploadOption(null)
                      }}
                      style={{
                        padding: '1rem',
                        background: cv.isCurrent ? '#f0f9ff' : '#f8fafc',
                        border: `2px solid ${cv.isCurrent ? '#3b82f6' : '#e2e8f0'}`,
                        borderRadius: '8px',
                        cursor: 'pointer',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                      }}
                    >
                      <div>
                        <div style={{ fontWeight: 600, color: '#1e293b', marginBottom: '0.25rem' }}>{cv.name}</div>
                        <div style={{ fontSize: '0.875rem', color: '#64748b' }}>{cv.date}</div>
                      </div>
                      {cv.isCurrent && (
                        <span style={{
                          padding: '0.25rem 0.75rem',
                          background: '#3b82f6',
                          color: 'white',
                          borderRadius: '12px',
                          fontSize: '0.75rem',
                          fontWeight: 600
                        }}>
                          Current
                        </span>
                      )}
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-end' }}>
                  <button className="btn-secondary" onClick={() => setUploadOption(null)}>
                    Back
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// Profile Section Component
function ProfileSection() {
  const [isEditing, setIsEditing] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [profileData, setProfileData] = useState({
    fullname: 'John Doe',
    email: 'john@example.com',
    phone: '+855 12 345 678',
    location: 'Phnom Penh, Cambodia',
    bio: 'Passionate software developer with 5+ years of experience in web development.',
    skills: ['JavaScript', 'React', 'Node.js', 'TypeScript', 'Python'],
    experience: '5+ years',
    education: 'Bachelor in Computer Science'
  })

  useEffect(() => {
    setMounted(true)
    
    if (typeof window !== 'undefined') {
      const currentUser = localStorage.getItem('currentUser')
      setIsLoggedIn(!!currentUser)
    }
  }, [])

  if (!isLoggedIn) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 2rem', maxWidth: '600px', margin: '0 auto' }}>
        <i className="fas fa-lock" style={{ fontSize: '4rem', color: '#3b82f6', marginBottom: '1.5rem', display: 'block' }}></i>
        <h2 style={{ fontSize: '2rem', marginBottom: '1rem', color: '#1e293b' }}>Sign In Required</h2>
        <p style={{ color: '#64748b', marginBottom: '2rem', fontSize: '1.1rem' }}>
          Please sign in to view and edit your profile information.
        </p>
        <Link href="/login">
          <button className="btn-primary" style={{ padding: '1rem 2rem', fontSize: '1.1rem' }}>
            <i className="fas fa-sign-in-alt"></i> Sign In Now
          </button>
        </Link>
      </div>
    )
  }

  return (
    <div className="profile-container" style={{ maxWidth: '1000px', margin: '0 auto', padding: '2rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h1>My Profile</h1>
        <button 
          className="btn-primary"
          onClick={() => setIsEditing(!isEditing)}
        >
          <i className={`fas fa-${isEditing ? 'times' : 'edit'}`}></i> {isEditing ? 'Cancel' : 'Edit Profile'}
        </button>
      </div>

      {/* Profile Header */}
      <div style={{
        background: 'white',
        padding: '2rem',
        borderRadius: '12px',
        marginBottom: '2rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <div style={{ display: 'flex', gap: '2rem', alignItems: 'center' }}>
          <div style={{
            width: '120px',
            height: '120px',
            borderRadius: '50%',
            background: 'var(--light-bg)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '3rem',
            color: 'var(--primary-orange)',
            flexShrink: 0
          }}>
            <i className="fas fa-user"></i>
          </div>
          <div style={{ flex: 1 }}>
            <h2 style={{ marginBottom: '0.5rem' }}>{profileData.fullname}</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', color: 'var(--light-text)' }}>
              <p style={{ margin: 0 }}><i className="fas fa-envelope"></i> {profileData.email}</p>
              <p style={{ margin: 0 }}><i className="fas fa-phone"></i> {profileData.phone}</p>
              <p style={{ margin: 0 }}><i className="fas fa-map-marker-alt"></i> {profileData.location}</p>
            </div>
          </div>
        </div>
      </div>

      {/* About Me */}
      <div style={{
        background: 'white',
        padding: '2rem',
        borderRadius: '12px',
        marginBottom: '2rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <i className="fas fa-user-circle" style={{ color: 'var(--primary-orange)' }}></i>
          About Me
        </h3>
        {isEditing ? (
          <textarea
            value={profileData.bio}
            onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
            rows={4}
            style={{
              width: '100%',
              padding: '0.75rem',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              fontSize: '1rem',
              fontFamily: 'inherit'
            }}
          />
        ) : (
          <p style={{ lineHeight: '1.8', color: 'var(--text-color)' }}>{profileData.bio}</p>
        )}
      </div>

      {/* Skills */}
      <div style={{
        background: 'white',
        padding: '2rem',
        borderRadius: '12px',
        marginBottom: '2rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <i className="fas fa-code" style={{ color: 'var(--primary-orange)' }}></i>
          Skills
        </h3>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          {profileData.skills.map((skill, index) => (
            <span key={index} style={{
              padding: '0.5rem 1rem',
              background: 'var(--light-bg)',
              borderRadius: '20px',
              fontSize: '0.9rem',
              fontWeight: 500
            }}>
              {skill}
            </span>
          ))}
        </div>
      </div>

      {/* Experience & Education */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
        <div style={{
          background: 'white',
          padding: '2rem',
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <i className="fas fa-briefcase" style={{ color: 'var(--primary-orange)' }}></i>
            Experience
          </h3>
          <p style={{ fontSize: '1.1rem', fontWeight: 600 }}>{profileData.experience}</p>
        </div>

        <div style={{
          background: 'white',
          padding: '2rem',
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <i className="fas fa-graduation-cap" style={{ color: 'var(--primary-orange)' }}></i>
            Education
          </h3>
          <p style={{ fontSize: '1.1rem', fontWeight: 600 }}>{profileData.education}</p>
        </div>
      </div>

      {isEditing && (
        <div style={{ marginTop: '2rem', textAlign: 'right' }}>
          <button 
            className="btn-secondary"
            onClick={() => setIsEditing(false)}
            style={{ marginRight: '1rem' }}
          >
            Cancel
          </button>
          <button 
            className="btn-primary"
            onClick={() => {
              alert('Profile updated successfully!')
              setIsEditing(false)
            }}
          >
            <i className="fas fa-save"></i> Save Changes
          </button>
        </div>
      )}
    </div>
  )
}
